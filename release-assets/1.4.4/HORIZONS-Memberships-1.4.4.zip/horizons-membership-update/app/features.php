<?php
return ['memberships_enabled'=>true,'transfer_sales_enabled'=>false];
